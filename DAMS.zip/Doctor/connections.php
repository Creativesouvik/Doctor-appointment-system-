<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "damsmsdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// echo "Connected successfully";

$Name = $_POST['Name'];
$MobileNumber = $_POST['MobileNumber'];
$Email = $_POST['Email'];
$age = $_POST['age'];
$Weight = $_POST['Weight'];
$Blood_Pressur = $_POST['Blood_Pressur'];
$Sugar = $_POST['Sugar'];
$Gender = $_POST['Gender'];
$Address = $_POST['Address'];
$AppointmentNumber = $_POST['AppointmentNumber'];


$sql = "INSERT INTO `tblappointment` (`ID`, `AppointmentNumber`, `Name`, `MobileNumber`, `Email`, `age`, `Gender`, `Weight`, `Blood_Pressur`, `Sugar`, `Address`, `Specialization`, `Doctor`, `ApplyDate`, `Remark`, `Status`, `UpdationDate`) VALUES (NULL, '$AppointmentNumber', '$Name', '$MobileNumber', '$Email', '$age', '$Gender', '$Weight', '$Blood_Pressur', '$Sugar', '$Address', 'Medicine', '1', current_timestamp(), NULL, NULL, NULL)";


if ($conn->query($sql) === false) {
  echo "Error: " . $sql . "<br>" . $conn->error;
} else {
  // echo "New record created successfully"."<br>";
  
  echo "Hi,$Name" . "<br>" ."Age :$age,Gender :$Gender ". "<br>" ."Address : $Address ". "<br>" . " Appointment Status : Successfull" . "<br>" . " Appointment ID : $AppointmentNumber " . "<br>";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Appointment Confirmation Receipt </title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
  <div class="col-md-12 text-center">
    <a href="index.php"><button type="button" class="btn btn-primary"> Back To Homepage</button></a>
    <button type="button" class="btn btn-primary" onclick="window.print();"> Print </button>
  </div>
</body>

</html>